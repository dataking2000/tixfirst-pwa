
const CACHE_NAME = 'tixfirst-cache-v1';
const OFFLINE_URL = '/';
const PRECACHE = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Install - cache files
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(PRECACHE))
  );
});

// Activate - clean up old caches
self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});

// Fetch - try network first, fallback to cache
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  // Let API requests go to network (they will be proxied by server)
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(fetch(event.request).catch(() => caches.match(OFFLINE_URL)));
    return;
  }

  event.respondWith(
    fetch(event.request).then(response => {
      // Optionally cache GET requests for same-origin
      if (event.request.method === 'GET' && response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      }
      return response;
    }).catch(() => caches.match(event.request).then(r => r || caches.match(OFFLINE_URL)))
  );
});
